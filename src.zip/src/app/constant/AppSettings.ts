export class AppSettings {
    public static menuBar:string[]=['Cutomer Care','Admin Care'];
    public static customerMenubarList:string[]=['Customer','Account','Statement'];
    public static CustomerSideMenuBarList:string[]=['Search','Add','Activation'];
    public static CustomerSearchSideMenuBarList:string[]=['CustomerInformation','AccountList','Contacts','AccessInformation','AuditTrail','Properties'];
}