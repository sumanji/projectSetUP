import { Injectable, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { AppSettings } from '../constant/AppSettings';



@Injectable()
export class MenuSideBarService {
  //sideMenuBar:Subject<string[]>=new Subject<string[]>();
   sideMenuBar = AppSettings.CustomerSideMenuBarList;
  constructor(){
  alert("inside the constructor of MenuSideBarService");
//this.sideMenuBar=[];
  }
  setSideMenuBar(newMenus: string[]) {
    alert("inside the setSideMenuBar of MenuSideBarService");  
    if (newMenus.length > 0) {
      for (const st of newMenus) {
        this.sideMenuBar.push(st);
      }
    }


  }
  getSideMenuBar(): string[] {
   // alert("inside the getSideMenuBar of MenuSideBarService");
    return this.sideMenuBar;
    //this.sideMenuBar.next(newMenus);
  }
}
