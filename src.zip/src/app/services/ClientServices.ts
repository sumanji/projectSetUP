import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class ClientService{

constructor(private http:HttpClient){

}
public getJSON():Observable<any>{
return this.http.get('./assets/myData.json').pipe(
    map((res)=>{
    return res;
    })
);}

}