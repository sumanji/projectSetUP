import { Component, OnInit,Input } from '@angular/core';
import {MenuSideBarService} from '../../services/menu-side-bar.service';
import {AppSettings} from '../../constant/AppSettings';
@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {

  

  constructor(private ser:MenuSideBarService) { }

  ngOnInit() {

   // this.ser.setSideMenuBar(AppSettings.CustomerSearchSideMenuBarList);
  
  }

}
