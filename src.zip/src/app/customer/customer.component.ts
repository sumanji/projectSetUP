import { Component, OnInit,DoCheck} from '@angular/core';
import {MenuSideBarService} from '../services/menu-side-bar.service';
import {Subscription} from 'rxjs';
import {AppSettings} from '../constant/AppSettings'
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
   styleUrls: ['./customer.component.css']
  
})
export class CustomerComponent implements OnInit,DoCheck {
  //status=true;
  menuList:string [];
 // sideMenuBarList:string[];
  constructor(private serv:MenuSideBarService) {
    this.menuList=AppSettings.customerMenubarList;
  
   // this.serv.setSideMenuBar(AppSettings.CustomerSideMenuBarList);
    //this.status=false;
 
  }

  ngOnInit() {
   // this.serv.setSideMenuBar([]);
  }

  ngDoCheck(){
// this.serv.sideMenuBar.subscribe(dataEmitted=>{
//   this.sideMenuBarList=dataEmitted;
//     });
//   
}
}
