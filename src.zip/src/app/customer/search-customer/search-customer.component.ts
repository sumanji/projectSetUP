import { Component, OnInit, Output, EventEmitter, DoCheck } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { ClientService } from '../../services/ClientServices';
import { AppSettings } from '../../constant/AppSettings';
import {MenuSideBarService } from '../../services/menu-side-bar.service';
@Component({
  selector: 'app-search-customer',
  templateUrl: './search-customer.component.html',
  styleUrls: ['./search-customer.component.css']
})
export class SearchCustomerComponent implements OnInit {
 private recordsPerPage:number=5;
  private status = true;
  private containsData = [];
  private headers = [];
  private subscribedResult: Subscription;
  private keyindex: string;
  filterString = "";
  column = "";
  ascOrder = true;


  
  searchForm = new FormGroup({
    searchBy: new FormControl(''),
    searchValue: new FormControl(''),
    searchValueBy: new FormControl('')
  });




  constructor(private router: Router,
    private activeRoute: ActivatedRoute,
    private dataservice: ClientService,
  private ser :MenuSideBarService) {
    console.log("inside the constructor of SearchCustomerComponent");

  }

  ngOnInit() {
console.log(Math.round(100/12));
    //this.searchSideMenu.push( AppSettings.CustomerSearchSideMenuBar);
    console.log("inside the ngOnInit of SearchCustomerComponent");

  }





  onSubmit() {
    console.log("inside the submit function of SearchCustomerComponent");
    console.log(this.searchForm.get('searchBy').value);
    console.log(this.searchForm.get('searchValue').value);
    console.log(this.searchForm.get('searchValueBy').value);


    this.dataservice.getJSON().subscribe(

      (data) => {

        let resources = data["tableHeader"];
        this.headers = [];
        for (let datafield of resources) {
          console.log("value of the header is" + datafield)
          this.headers.push(datafield);
        }
        let tablevalue = data['tabledta'];
        if (this.searchForm.get('searchBy').value !== "" || this.searchForm.get('searchValue').value !== "" || this.searchForm.get('searchValueBy').value) {
          this.containsData = [];
          for (let datafield of tablevalue) {
            this.containsData.push(datafield);
            //console.log(datafield);
          }
        }
      }

    );

  }



  onReset() {
    if (this.searchForm.valid) {
      console.log("Form Submitted!");
      this.searchForm.reset();
    }
  }
  ngOnDestroy() {

  }

  onClickHeaders(header: string) {
    alert(header);
    this.column = header;
    this.ascOrder = !this.ascOrder;
  }

  onClicCustomerList(id: string) {
    if(this.status){
  alert("inside  onClicCustomerList(id: string) of the search customer ")
     this.ser.setSideMenuBar(AppSettings.CustomerSearchSideMenuBarList);
    this.router.navigate(['id'],{relativeTo:this.activeRoute});
    this.status=false;
    }
  
  }

  onclickPagination(pagesize:number,allList:number):number[]{
  const  paginationarr=[];
    if(pagesize>allList){
console.log(Math.round(100%12));
    }
return null;

  }
}
