import { Component ,OnInit} from '@angular/core';
import {AppSettings} from './constant/AppSettings';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
 menuBar:string[];
  title = 'Customer Application';
  ngOnInit(){
    this.menuBar=AppSettings.menuBar;
   // console.log(AppSettings.menuBar);
  }
}
