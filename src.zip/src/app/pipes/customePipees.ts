import {PipeTransform,Pipe} from '@angular/core';

@Pipe({
    name:"sortPipe"
})
export class customPipe implements PipeTransform {
     transform(value:any,column:string,order:string):any{
        
         if(value.length===0||column==="" ){
return value;
         }
const resultarr=[];

value.sort((a:any,b:any) =>{
    if(order){
        //ascending
       
if(a[column]<b[column]){
        return -1;
    }
    else if(a[column]>b[column]){
        return 1;

    }
    else{
        return 0;
    }
    }
else{
    //descending
    if(a[column]>b[column]){
        return -1;
    }
    else if(a[column]<b[column]){
        return 1;

    }
    else{
        return 0;
    }
}
} 
);
// for(const item of value){
//     if(item[column]===filter){
//         resultarr.push(item);
//     }

//}
return value;

         }
       
     

}