import { Component, OnInit, DoCheck } from '@angular/core';
import { AppSettings } from '../constant/AppSettings';
import { Router, ActivatedRoute } from '@angular/router';
import { MenuSideBarService } from '../services/menu-side-bar.service';

@Component({
  selector: 'app-side-navigation',
  templateUrl: './side-navigation.component.html',
  styleUrls: ['./side-navigation.component.css']
})
export class SideNavigationComponent implements OnInit, DoCheck {
  sidenav: string[] = [];
  constructor(private router: Router, private route: ActivatedRoute, private ser: MenuSideBarService) { }

  ngOnInit() {
    //this.sidenav = this.ser.getSideMenuBar();

    //     if(this.sidenav.length>0){
    //       this.router.navigate([this.sidenav[0]],{
    //         relativeTo:this.route
    //       });
    //     }
    //     this.ser.sideMenuBar.subscribe(
    //       (data:string[])=>{
    //         for(const daataEntity of data){
    //  this.sidenav.push(daataEntity);
    //         }


    //       }
    //     );
  }


  ngDoCheck() {
    this.sidenav = this.ser.getSideMenuBar();
  }
}
