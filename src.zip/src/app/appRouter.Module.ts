import { NgModule } from '@angular/core';
import { Routes, Router, RouterModule } from '@angular/router';

import { CustomerComponent } from './customer/customer.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { HeaderComponent } from './header/header.component';
import { SearchCustomerComponent } from './customer/search-customer/search-customer.component';
import {SideNavigationComponent} from './side-navigation/side-navigation.component';
import {CustomerDetailsComponent} from './customer/customer-details/customer-details.component';

const routes: Routes = [{
    path: "",
    component: NotFoundComponent
},
{
    path: "Cutomer Care",
    component: CustomerComponent,
    children: [{
        path: "Customer",
        component: SideNavigationComponent,
        children: [{
            path: 'Search',
            component: SearchCustomerComponent
        },
    {
            path: 'Search/:id',
            component: CustomerDetailsComponent
        }]
    },
    {
        path: "Account",
        component: NotFoundComponent
    },
    {
        path: "Statement",
        component: NotFoundComponent
    }

    ]
},

{
    path: "**",
   redirectTo:""
}

];



@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRouteRModule {

}