import { NgModule } from '@angular/core';

import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AppRouteRModule } from './appRouter.Module';
import { NotFoundComponent } from './not-found/not-found.component';
import { CustomerComponent } from './customer/customer.component';
import {customPipe} from './pipes/customePipees';
import { MenuSideBarService } from './services/menu-side-bar.service';
import { ClientService } from './services/ClientServices';
import { SearchCustomerComponent } from './customer/search-customer/search-customer.component';

import { SideNavigationComponent } from './side-navigation/side-navigation.component';
import { CustomerDetailsComponent } from './customer/customer-details/customer-details.component';
@NgModule({
  declarations: [
    AppComponent,

    HeaderComponent,
    FooterComponent,
    NotFoundComponent,
    CustomerComponent,

    SearchCustomerComponent,

   customPipe,

    SideNavigationComponent,

    CustomerDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRouteRModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [MenuSideBarService,ClientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
